import { Component } from '@angular/core';

@Component({
  selector: 'project',
  standalone: false,
  templateUrl: './project.component.html',
  styleUrl: './project.component.css'
})
export class ProjectComponent {
  projects = [
    {
      id: 1,
      name: "E-commerce Website",
      desc: "A fully responsive e-commerce platform built with React and Node.js.",
      types: ["React", "Node.js", "MongoDB"],
      img: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80",
    },
    {
      id: 2,
      name: "Task Management App",
      desc: "A fully responsive e-commerce platform built with React and Node.js.",
      types: ["React", "Node.js", "MongoDB"],
      img: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80",
    },
    {
      id: 3,
      name: "E-commerce Website 2",
      desc: "A fully responsive e-commerce platform built with React and Node.js.",
      types: ["React", "Node.js", "MongoDB"],
      img: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80",
    },
  ];
}
